import axios from 'axios';
const KEY = 'AIzaSyARlbwQjc0i3_3csoj9UUHYsfz6GUy4aYI';

export default axios.create({
    baseURL: 'https://www.googleapis.com/youtube/v3/',
    params: {
        part: 'snippet',
        maxResults: 5,
        key: KEY
    }
})