import React from 'react';

/* state = {
    currentVideo: 0,
    mute: false,
    shouldPlay: true,
 }
 handlePlayAndPause = () => {
   this.setState((prevState) => ({
      shouldPlay: !prevState.shouldPlay
   }));
 }
 handleVolume = () => {
    this.setState((prevState) => ({
       mute: !prevState.mute
    }));
 }
 forwardButton = () => {
    if (this.state.currentVideo != VIDEOS.length-1) {
       this.setState({currentVideo: this.state.currentVideo + 1});
    } else {
       this.setState({currentVideo: 0});
    }
 }
 backButton = () => {
    if (this.state.currentVideo != 0) {
       this.setState({currentVideo: this.state.currentVideo - 1});
    } else {
       this.setState({currentVideo: VIDEOS.length-1});
    }
 }
*/


const VideoDetail = ({ video }) => {
    let VIDEOS = video;
    let currentVideo = video;
    if (!video) {
        return <div>Loading ...</div>;
    }
    
    const state = {
        currentVideo: 0,
        mute: false,
        shouldPlay: true,
     }
    
      function handlePlayAndPause  (e) {
        this.setState((prevState) => ({
           shouldPlay: !prevState.shouldPlay
        }));
      }
      function handleVolume  (e) {
         this.setState((prevState) => ({
            mute: !prevState.mute
         }));
      }
      function forwardButton (e) {
        //  if (this.state.currentVideo != VIDEOS.length-1) {
        //     this.setState({currentVideo: this.state.currentVideo + 1});
        //  } else {
        //     this.setState({currentVideo: 0});
        //  }
      }
      function backwardButton (e) {
        //  if (this.state.currentVideo != 0) {
        //     this.setState({currentVideo: this.state.currentVideo - 1});
        //  } else {
        //     this.setState({currentVideo: VIDEOS.length-1});
        //  }
      }


    const videoSrc = `https://www.youtube.com/embed/${video.id.videoId}`;
    console.log((video));

    return (
        <div>
            <div className='ui embed'>
                <iframe src={videoSrc} allowFullScreen title='React YouTube' />    

            </div>
            <div className='ui segment'>
                <button onClick={forwardButton}>Previous </button>
                <button onClick={backwardButton}>Next</button>
                <h4 className='ui header'>{video.snippet.title}</h4>
                <p>{video.snippet.description}</p>
            </div>
        </div>

    )
}

export default VideoDetail;